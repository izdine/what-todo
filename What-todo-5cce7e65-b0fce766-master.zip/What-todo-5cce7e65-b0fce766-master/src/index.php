<?php
require_once "./controllers/AccessController.class.php";
require_once "..//vendor/autoload.php";
require_once 'rb.php';
R::setup('mysql:host=localhost;dbname=Todo-DB', 'root', '');
$loader = new \Twig\Loader\FilesystemLoader('./views');
$twig = new \Twig\Environment($loader, []);
$assetfunction = new \Twig\TwigFunction('asset', function ($asset) {
    return "/dist/$asset"; 
});
$twig->addFunction($assetfunction);
$url = $_SERVER['REQUEST_URI'];
$split = explode("/", $url);
$cont = ucfirst($split[1]);
$meth = ucfirst($split[2]);
$rmeth = $_SERVER['REQUEST_METHOD'];
if ($rmeth == "POST") {
    $meth = $meth . "Post";
}
if ($rmeth ==  "DELETE") {
    $meth = $meth . "Delete";
}
if ($rmeth == "PUT") {
    $meth = $meth . "Put";
}
if (!file_exists("./controllers//" . $cont . "Controller.class.php")) {
    $var = new accessController();
    $var->notFound();
} else {
    $link = "./controllers//" . $cont . "Controller.class.php";
    include_once $link;
    $class = $cont . "Controller";
    $instance = new $class($twig);
    if (!method_exists($instance, $meth)) {
        $var = new accessController();
        $var->notFound();
    } else {
        $instance->$meth($twig);
    }
}

