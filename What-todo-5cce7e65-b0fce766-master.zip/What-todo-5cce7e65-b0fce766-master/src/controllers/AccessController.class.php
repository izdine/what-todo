<?php
require_once "rb.php";
class AccessController
{
    public function notFound()
    {
        http_response_code(404);
        echo "<h1> 404 </h1> <br> <h2> Page not found </h2>";
    }
}
