<?php
require_once "rb.php";
session_start();
class UserController
{
    private $twig;
    public function __construct($twig)
    {
        $this->twig = $twig;
    }
    public function login()
    {
        if(!isset($_SESSION['session_token'])) {
            $user = $this->twig->load('userLogin.html');
            echo $user->render();
        } else {
            echo "User has been logged in already!";
            echo "<br><a href='/content/index'>Back to index</a>";

        }
    }
    public function loginPost()
    {
        $username = !empty($_POST['username']) ? TRIM($_POST['username']) : null;
        $pwAttempt = !empty($_POST['password']) ? TRIM($_POST['password']) : null;
        $user = R::getRow(
            'SELECT id, username, password FROM users WHERE username = :username',
            array(':username'=>$username)
        );
        if ($pwAttempt == $user['password']) {
            //Session aanmaken
            while (true) {
                $token = $this->generateToken();
                if (R::findOne('active_sessions', 'token = ?', [$token]) == null) {
                    break;
                }
            }
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['logged_in'] = time();
            $temp = R::exec('INSERT INTO active_sessions (user_id, token) VALUES ("' . $user['id'] . '" , "' . $token . '")');
            $_SESSION['session_token'] = $token;
            header("location: /content/index");
        } else {
            die('Invalide gebruikersnaam/wachtwoord combinatie, probeer het opnieuw');
        }
    }
    public function generateToken($length = 100)
    {
        $token = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $tokenLength = strlen($token);
        $randomToken = '';
        for ($i = 0; $i < $length; $i++) {
            $randomToken .= $token[rand(0, $tokenLength - 1)];
        }
        return $randomToken;
    }
    public function logOut()
    {
        if(isset($_SESSION['session_token'])) {
            unset($_SESSION['session_token']);
            $active_session = R::load('active_sessions', $_SESSION['user_id']);
            R::trash($active_session);
            header("location: /user/login");
        } else {
            echo "User isn't Logged In!";
        }
    }
}
class UserService
{
    public function validateLoggedIn()
    {
        if (!isset($_SESSION['session_token'])) {
            header('Location: /user/login');
        }
    }
    public function checkUserOP()
    {
        $noteId = contentController::getNoteId();
        $userId = R::getAll("SELECT user_id FROM todo WHERE id = '" . $noteId . "'");
        if (!$_SESSION['user_id'] === $noteId) {
            header('Location: /content/index');
            exit;
        }
    }
}
?>
