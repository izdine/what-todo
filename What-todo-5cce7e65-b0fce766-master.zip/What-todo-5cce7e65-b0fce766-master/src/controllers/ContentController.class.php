<?php

require_once "rb.php";
require_once "UserController.class.php";
require_once "UserService.class.php";

class ContentController
{
    private $twig;
    public function __construct($twig)
    {
        $this->twig = $twig;
    }
    public function index()
    {
        $this->checkUser();
        $all = R::getAll('SELECT * FROM `Todo-DB`.todo WHERE user_id = "' . $_SESSION['user_id'] . '"');
        $index = $this->twig->load('contentIndex.twig');
        echo $index->render(['notes' => $all]);
    }
    public function add()
    {
        $this->checkUser();
        $add = $this->twig->load('contentAdd.html');
        echo $add->render();
    }
    public function addPost()
    {
        $this->checkUser();
        $content = R::dispense('todo');
        $content->note = $_POST['contentAdd'];
        $content->user_id = $_SESSION['user_id'];
        $id = R::store($content);
        header('Location: /content/index');
    }
    public function edit()
    {
        $this->checkUser();
        $this->checkUserOP();
        $noteID = $this->getNoteId();
        $editID = R::getAll('SELECT * FROM todo WHERE todo.id = ' . $noteID . ';');
        $edit = $this->twig->load('contentEdit.twig');
        echo $edit->render(['note' => $editID[0]['note'], 'id' => $editID[0]['id'], 'user_id' => $_SESSION['user_id']]);
    }
    public function editPost()
    {
        $this->checkUser();
        $this->checkUserOP();
        $content = R::dispense('todo');
        $content->import($_POST, 'note,id,user_id');
        $query = R::store($content);
        header('Location: /content/index');
    }
    public function indexDelete()
    {
        $this->checkUser();
        $this->checkUserOP();
        $noteID = $this->getNoteId();
        $deleteNote = R::load('todo', $noteID);
        R::trash($deleteNote);
        echo "<h2>Post verwijderd </h2>";
        $this->index();
    }
    public function markasDone()
    {
        $this->checkUser();
        $this->checkUserOP();
        $noteID = $this->getNoteId();
        $query = R::exec('UPDATE todo SET completed_at= CURRENT_TIMESTAMP WHERE id="' . $noteID . '"');
        header('Location: /content/index');
    }
    public static function getNoteId()
    {
        $url = $_SERVER['REQUEST_URI'];
        $split = explode("/", $url);
        if (isset($split[3])) {
            $noteID = $split[3];
        }
        return $noteID;
    }
    public function checkUser()
    {
        $userCheck = new UserService();
        $userCheck->validateLoggedIn();
    }
    public function checkUserOP()
    {
        $checkOP = new UserService();
        $checkOP->checkUserOP();
    }
}
