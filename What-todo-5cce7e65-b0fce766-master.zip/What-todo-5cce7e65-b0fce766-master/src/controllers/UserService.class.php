<?php
require_once "rb.php";
require_once "ContentController.class.php";
session_start();
class UserService
{
    public function validateLoggedIn()
    {
        if (!isset($_SESSION['session_token'])) {
            header('Location: /user/login');
        }
    }
    public function checkUserOP()
    {
        $noteId = contentController::getNoteId();
        $userId = R::getAll("SELECT user_id FROM todo WHERE id = '" . $noteId . "'");
        if (!$_SESSION['user_id'] === $noteId) {
            header('Location: /content/index');
            exit;
        }
    }
}
?>
