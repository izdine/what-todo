CREATE DATABASE `Todo-DB`;

USE `Todo-DB`;

CREATE TABLE users(
	id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
	username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL
    );
    
INSERT INTO users (username, password) VALUES
('Yari', 'BigDaddy'),
('Youssef', 'iHateItHere'),
('Iz-dine', 'Aquarion'),
('Silvester', 'Populist');

CREATE TABLE active_sessions(
	id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    user_id INT NOT NULL, 
    token CHAR(100) NOT NULL UNIQUE,
    FOREIGN KEY (user_id) REFERENCES users(id)
    );

CREATE TABLE todo (
	id INT PRIMARY KEY NOT NULL AUTO_INCREMENT, 
    user_id INT NOT NULL, 
    note VARCHAR(100) NOT NULL,
    completed_at DATETIME NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
    );
